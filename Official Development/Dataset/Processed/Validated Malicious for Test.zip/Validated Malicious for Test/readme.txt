The datasets in this folder contain the three malware types specified by VirusTotal for each sample.

This could be useful during model evaluation to determine what malware types does the model perform well which will be supplemented by the findings on Dataset Analysis. 

(i.e., knowing the composition of malware types in the dataset may establish expectations regarding the model's performance/capabilities).